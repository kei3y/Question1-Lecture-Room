/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package victoriaProject;

/**
 *
 * @author Kei3ron
 */
public class lectureRoom {
    private int students;
    private boolean[] lights;

    public lectureRoom() {
        students = 0;
        lights = new boolean[3]; 
    }
    public void addStudents(int number) {
        students += number;
        System.out.println(number + " students added. Total students now: " + students);
    }
    public void removeStudents(int number) {
        if (number > students) {
            students = 0;
        } else {
            students -= number;
        }
        System.out.println(number + " students removed. Total students now: " + students);
    }
    public void turnOnLight(int lightNumber) {
        if (lightNumber >= 1 && lightNumber <= 3) {
            lights[lightNumber - 1] = true;
            System.out.println("Light " + lightNumber + " turned on.");
        } else {
            System.out.println("Invalid light number. Please choose 1, 2, or 3.");
        }
    }

    public void turnOffLight(int lightNumber) {
        if (lightNumber >= 1 && lightNumber <= 3) {
            lights[lightNumber - 1] = false;
            System.out.println("Light " + lightNumber + " turned off.");
        } else {
            System.out.println("Invalid light number. Please choose 1, 2, or 3.");
        }
    }

    public void status() {
        System.out.println("Students in room: " + students);
        for (int i = 0; i < lights.length; i++) {
            String state = lights[i] ? "on" : "off";
            System.out.println("Light " + (i + 1) + " is " + state + ".");
        }
    }
}
