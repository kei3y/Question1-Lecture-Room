/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package victoriaProject;

/**
 *
 * @author Kei3ron
 */
 import java.util.Scanner;
public class easyReader {
    public static void main(String[] args) {
        lectureRoom room = new lectureRoom();
        Scanner Scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\nMain Menu:");
            System.out.println("W - Add students");
            System.out.println("X - Remove students");
            System.out.println("Y - Turn on a light");
            System.out.println("Z - Turn off a light");
            System.out.println("Q - Quit");

            System.out.print("Choose an option: ");
            String choice = Scanner.nextLine().toUpperCase();

            switch (choice) {
                case "W":
                    System.out.print("Enter the number of students to add: ");
                    int addNumber = Scanner.nextInt();
                    Scanner.nextLine(); // Consume newline
                    room.addStudents(addNumber);
                    break;
                    
                case "X":
                    System.out.print("Enter the number of students to remove: ");
                    int removeNumber = Scanner.nextInt();
                    Scanner.nextLine(); // Consume newline
                    room.removeStudents(removeNumber);
                    break;
                    
                case "Y":
                    System.out.print("Enter the light number to turn on (1, 2, or 3): ");
                    int lightOnNumber = Scanner.nextInt();
                    Scanner.nextLine(); // Consume newline
                    room.turnOnLight(lightOnNumber);
                    break;
                    
                case "Z":
                    System.out.print("Enter the light number to turn off (1, 2, or 3): ");
                    int lightOffNumber = Scanner.nextInt();
                    Scanner.nextLine(); // Consume newline
                    room.turnOffLight(lightOffNumber);
                    break;
                    
                case "Q":
                    System.out.println("Quitting program.");
                    running = false;
                    break;
                    
                default:
                    System.out.println("Invalid choice. Please choose a valid option.");
            }

            room.status();
        }

        Scanner.close();
    }
}
